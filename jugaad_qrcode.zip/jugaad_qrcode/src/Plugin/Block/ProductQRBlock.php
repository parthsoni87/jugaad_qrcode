<?php

namespace Drupal\jugaad_qrcode\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\node\NodeInterface;
use Drupal\Core\Url;

/**
 * Provides a 'ProductQRBlock' block.
 *
 * @Block(
 *  id = "product_qrblock",
 *  admin_label = @Translation("Product qrblock"),
 * )
 */
class ProductQRBlock extends BlockBase implements ContainerFactoryPluginInterface {

  /**
   * Drupal\Core\Entity\EntityTypeManagerInterface definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    $instance = new static($configuration, $plugin_id, $plugin_definition);
    $instance->entityTypeManager = $container->get('entity_type.manager');
    $instance->routeMatch = $container->get('current_route_match');
    return $instance;
  }

  /**
   * {@inheritdoc}
   */
  public function build() {
    $build = $qrcodeImage = [];
    $node = $this->routeMatch->getParameter('node');
    if ($node instanceof NodeInterface) {
      // You can get nid and anything else you need from the node object.
      $nid = $node->id();
      if ($node->hasField('field_app_purchase_link') && !empty($node->get('field_app_purchase_link')->first())) {
        $appLink = $node->get('field_app_purchase_link')->getString();
        $option = [
          'query' => ['path' => $appLink],
        ];
        $uri = Url::fromRoute('jugaad_qrcode.qr.url', [], $option)
          ->toString();
        $qrcodeImage = [
          '#theme' => 'image',
          '#uri' => $uri
        ];
      }
    }
    $build['#theme'] = 'jugaad_qrcode';
    $build['#image'] = $qrcodeImage;

    return $build;
  }

}
